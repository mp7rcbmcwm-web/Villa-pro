SınavYıldızım — Gelişim Merkezi sürümü
====================================

İçerik: index.html, manifest.json, ikonlar, logo ve Service Worker (v2).

Eklenen özellikler:
- Yanlış sorular için 1, 3, 7 ve 21 günlük tekrar sırası
- 25 dakikalık odaklanma sayacı ve çalışma süresi kaydı
- Deneme neti kaydı, son 5 deneme ortalaması ve hedef farkı
- Konu ilerleme matrisi
- XP ve günlük çalışma serisi takibi
- CSV deneme raporu, JSON yedek, gece modu ve PWA kurulum düğmesi

Sınırlar:
- Kayıtlar yerel tarayıcıda saklanır; gerçek bulut eşitleme etkin değildir.
- Firebase/Firestore için proje, kimlik doğrulama, veri modeli ve güvenlik kuralları yapılandırılmalıdır.
- JavaScript sözdizimi Node.js ile kontrol edildi. Gerçek iOS/Android cihaz ve canlı hosting testi yapılmadı.
- PWA kurulum/Service Worker özellikleri HTTPS üzerinde yayımlama gerektirir.
